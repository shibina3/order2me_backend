const { Pool } = require('pg');

// Set up a connection pool
const pool = new Pool({
    user: 'shibina',
    host: 'database-1.c5c4wam0egxq.us-east-1.rds.amazonaws.com',
    database: 'order2me',
    password: 'ramyasil2024',
    port: 5432,
});

const userData = {
    storeData: async (data) => {
        const query = `
            INSERT INTO users (username, email, mobile, password, admin, delivery_partner)
            VALUES ($1, $2, $3, $4, $5, $6)
        `;
        const values = [data.username, data.email, data.mobile, data.password, false, false];

        try {
            await pool.query(query, values);
        } catch (error) {
            console.error("Error storing data:", error);
            throw error;
        }
    },
    getData: async (email) => {
        const query = `SELECT * FROM users WHERE email = $1`;
        try {
            const res = await pool.query(query, [email]);
            return res.rows[0];
        } catch (error) {
            console.error("Error retrieving data:", error);
            return null;
        }
    },
    isUserRegistered: async (email) => {
        const data = await userData.getData(email);
        return !!data;
    },
    deRegisterUser: async (email) => {
        const query = `DELETE FROM users WHERE email = $1`;
        try {
            await pool.query(query, [email]);
            return true;
        } catch (error) {
            console.error("Error deregistering user:", error);
            return false;
        }
    }
}

exports.handler = async (event) => {
    let client = await pool.connect();
    try {
        const body = event.body ? JSON.parse(event.body) : null;

        if(body.path === "/register") {
            const { email, mobile, password, username } = body;
            try {
                if (await userData.isUserRegistered(email)) {
                    return res.status(400).json({ error: 'User already registered' });
                }
        
                const data = {
                    username: username,
                    email: email,
                    mobile: mobile,
                    password: password
                };
        
                await userData.storeData(data);
        
                return {
                    statusCode: 200,
                    body: JSON.stringify({ message: 'User registered successfully' }),
                };
            } catch (error) {
                return {
                    statusCode: 500,
                    body: JSON.stringify({ error: 'Error registering user' }),
                };
            }
        }
    } catch (error) {
        console.error('Database query failed', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Database query failed' }),
        };
    } finally {
        // Release the client back to the pool
        if (client) {
            client.release();
        }
    }
};
